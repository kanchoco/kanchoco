package markerInterFaceTest;

public interface HerbivoreMarker {
//	Herbivore 타입으로 묶기위해 생성된 마커인터페이스
}
