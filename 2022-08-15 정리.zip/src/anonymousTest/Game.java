package anonymousTest;

public interface Game {
	public void play();
	public void exit();
	
}
