package anonymousTask;

public interface Form {		//양식, Building 클래스에 전달한다.
   public String[] getMenu();
   public void sell(String order);
}