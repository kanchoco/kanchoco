package markerInterFaceTest;

public class Dog extends Animal {
//	Animal클래스를 부모로 상속

}
