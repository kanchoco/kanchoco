package markerInterFaceTest;

public class Bear extends Animal implements CarnivoreMarker{
//	Animal클래스를 부모로, CarnivoreMarker(그룹화)를 지정한 클래스 Bear

}
