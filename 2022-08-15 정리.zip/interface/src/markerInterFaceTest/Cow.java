package markerInterFaceTest;

public class Cow extends Animal implements HerbivoreMarker{
//	Animal클래스를 부모로, HerbivoreMarker(그룹화)를 지정한 클래스 Cow

}
