package markerInterFaceTest;

public class Animal {
//	Animal타입을 위해 만든 클래스

}
