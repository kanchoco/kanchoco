package markerInterFaceTest;

public interface CarnivoreMarker {
//	Carnivore타입으로 묶기 위해 생성된 마커인터페이스
}
