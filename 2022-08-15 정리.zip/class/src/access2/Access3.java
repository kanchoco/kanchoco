package access2;

import access1.Access1;

public class Access3 extends Access1 {
	public static void main(String[] args) {
		Access3 a1 = new Access3();
		
	}
}
